tema de la fizica de pe 02.02.2026
